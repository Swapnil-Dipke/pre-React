import { createStore } from "redux";

// //Initial State
// const InitialState = {
// counter :0,
// newCounter :0,
// };

// //reducer
// const reducer =(state=InitialState,action)=>{
// return{
// counter: state.counter+1,
// newCounter : state.newCounter +1,
// }
// }

// //store
// const store = createStore(reducer);
// export default store;





//Initial State
const InitialState = {
    counter :0,
    newCounter :0,
    };
    
    //reducer
    const reducer =(state=InitialState,action)=>{

        const {type} = action;

        switch (type) {
            case "increement": return {counter : state.counter + 2} ;
          
        
            case "decreement": return { counter : state.counter -1 };
            
        
            case "multiply": return{ counter : state.counter * 2};
        
        
            case "division": return{ counter : state.counter / 2};
            
            
            case "modulus": return{ counter : state.counter % 3};




            case "increement": return {counter : state.newCounter + 2} ;
          
        
            case "decreement": return { counter : state.newCounter -1 };
            
        
            case "multiply": return{ counter : state.newCounter * 2};
        
        
            case "division": return{ counter : state.newCounter / 2};
            
            
            case "modulus": return{ counter : state.newCounter % 3};
            
            default: return state;



                
        }




  
    }
    
    //store
    const store = createStore(reducer);
    export default store;