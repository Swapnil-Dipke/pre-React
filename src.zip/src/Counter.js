
import React, {Component} from 'react';
import { connect} from 'react-redux';

class Counter extends Component{

render(){
    console.log(this.props);
    return <> <h1> Counter :  { this.props.counter}</h1>
    <button onClick={this.props.increement}> Increement</button>
    <button onClick={this.props.decreement}> decreement</button>
    </>
}

}


const  mapStatesToProps = (state) =>{
return{
    counter : state.counter,
}
}



const mapDispatchToProps = (dispatch) =>{
    return{
        increement :()=>{dispatch({type: "increement"})},
        decreement :()=>{dispatch({type: "decreement"})},
        multiply   :()=>{dispatch({type: "multiply"})}
      


        
    }

};

export default connect(mapStatesToProps, mapDispatchToProps)(Counter);