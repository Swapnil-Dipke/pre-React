import { Component } from "react";
import { connect } from "react-redux";


class NewCounter extends Component{
render(){
    console.log(this.props);
    return <><h1> newCounter : {this.props.NewCounter}</h1>
              <button onClick={this.props.increement}> Decreementer </button>
            <button onClick={this.props.decreement}> Decreementer </button>
</>
}


}

const mapStatesToProps= (state) =>{
    return {
        NewCounter : state.NewCounter,
    }

}


const mapDispatchToProps=(dispatch) =>{
    return{
        increement : () =>{dispatch({type : "increement"})},
        decreement : () =>{dispatch({type : "decreement"})},
    }
}


export default connect(mapStatesToProps)(NewCounter);